###################
What is CodeIgniter
###################

CodeIgniter is an Application Development Framework - a toolkit - for people
who build web sites using PHP. Its goal is to enable you to develop projects
much faster than you could if you were writing code from scratch, by providing
a rich set of libraries for commonly needed tasks, as well as a simple
interface and logical structure to access these libraries. CodeIgniter lets
you creatively focus on your project by minimizing the amount of code needed
for a given task.


<li><b>Originally created and manipulated by ahmad solehin</b></li>
<li>very simple code to use with</li>

*******************
# Screenshot
*******************

![aa](https://cloud.githubusercontent.com/assets/12325386/26042558/14e482d0-3969-11e7-9390-2ee64e06d1b8.JPG)
<br>
![aa](https://cloud.githubusercontent.com/assets/12325386/26043229/49cb5a14-396e-11e7-9a2f-9c6c40c70c5a.JPG)
<br>
![aa](https://cloud.githubusercontent.com/assets/12325386/26043317/da3fa06e-396e-11e7-92e2-e06686a05d41.JPG)

<br>

# Link to tutorial
<br>

https://www.youtube.com/watch?v=1Oh2bNvH5Nw&t=14s
