<script src="<?php echo base_url('assets/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script>
<link href="<?php echo base_url('assets/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet">
<style type="text/css">
    #buangLine {
        border: none;
        background-color: transparent;
        resize: none;
        outline: none;
    }
</style>
<div class="box-header with-border">
    <div class="col-md-6">
        <h3 class="box-title">User Information</h3>
    </div>
</div>
<div id="signupalert" class="alert alert-danger">
    <span></span>
</div>

<?php foreach ($output as $data): ?>
    <form action="#" id="form" class="form-horizontal">
        <div class="form-body">
            <div class="form-group">
                <label class="control-label col-md-3">First Name</label>
                <div class="col-md-9">
                    <input name="id" placeholder="First Name" class="form-control" value="<?php echo $data->users_id; ?>" type="hidden">
                    <input name="firstName" placeholder="First Name" class="form-control" value="<?php echo $data->first_name; ?>" type="text">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3">Last Name</label>
                <div class="col-md-9">
                    <input name="lastName" placeholder="Last Name" class="form-control" value="<?php echo $data->last_name; ?>" type="text">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3">Username</label>
                <div class="col-md-9">
                    <input name="username" placeholder="Username" class="form-control" value="<?php echo $data->username; ?>" type="text">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3">Email</label>
                <div class="col-md-9">
                    <input name="email" placeholder="Email" class="form-control" value="<?php echo $data->email; ?>" type="email">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3">Phone</label>
                <div class="col-md-9">
                    <input name="phone" placeholder="00000000000" class="form-control" value="<?php echo $data->phone; ?>" type="tel">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3">Password</label>
                <div class="col-md-9">
                    <input name="password" placeholder="" class="form-control" value="<?php echo $data->password; ?>" type="password">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3">Confirm Password</label>
                <div class="col-md-9">
                    <input name="confirm_password" placeholder="" class="form-control" value="<?php echo $data->password; ?>" type="password">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3">Address</label>
                <div class="col-md-9">
                    <textarea name="address" placeholder="Address" class="form-control">
                        <?php echo $data->address; ?>
                    </textarea>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3">Date of Birth</label>
                <div class="col-md-9">
                    <input name="dob" placeholder="yyyy-mm-dd" class="form-control datepicker" type="text" value="<?php echo $data->dob; ?>">
                </div>
            </div>
        </div>
    </form>
<?php endforeach; ?>
<div class="modal-footer">
    <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
</div>
<!-- /.box -->
<script>    
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top auto",
        todayBtn: true,
        todayHighlight: true,
    });

    function save() {
        var url;
        url = "<?php echo site_url('account/update')?>";

        // ajax adding data to database
        $.ajax({
            url: url,
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data) {
                if (data.status == 'success') {
                    $("#signupalert").html("Success");
                } else {
                    $("#signupalert").html(data.message);
                    //alert(data.message);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert('Error adding / update data');
            }
        });
    }
</SCRIPT>